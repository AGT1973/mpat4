
# event_bus

## Objetivo

Infraestructura de eventos cognitivos.

## Qué debe hacer el alumno

- Analizar contratos
- Diseñar eventos
- Definir interfaces
- Proponer schemas
- Documentar flujo
- Preparar relay

## Lenguajes sugeridos

- Python
- Rust
- YAML
- JSON
- Markdown

## Resultado esperado

Un subsistema documentado y listo para implementación futura.

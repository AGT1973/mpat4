
# memory_fabric

## Objetivo

Subsistema de memoria cognitiva distribuida.

## Qué debe hacer el alumno

- Analizar contratos
- Diseñar eventos
- Definir interfaces
- Proponer schemas
- Documentar flujo
- Preparar relay

## Lenguajes sugeridos

- Python
- Rust
- YAML
- JSON
- Markdown

## Resultado esperado

Un subsistema documentado y listo para implementación futura.

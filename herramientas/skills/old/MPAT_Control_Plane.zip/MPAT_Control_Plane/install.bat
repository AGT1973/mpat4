
@echo off
echo Installing MPAT Control Plane...

python -m venv venv

call venv\Scripts\activate

pip install -r requirements.txt

echo Installation complete.
pause

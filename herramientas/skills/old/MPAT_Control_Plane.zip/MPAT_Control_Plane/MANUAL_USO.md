
# MPAT Control Plane Manual

## Tabs

### Projects
Creates and manages isolated cognitive infrastructures.

### Students
Each student:
- requires a project
- can only have one active project
- receives a browser runtime profile

### Fabric Home
Represents the human cognitive runtime.

Includes:
- browser runtime
- relay state
- session continuity
- memory continuity

## Browser Runtime

Each student gets:

browser_runtime/student_name/

This represents:
- operational identity
- session continuity
- runtime context

## Installation

Run:
install.bat

Then:
run.bat

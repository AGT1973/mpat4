
from flask import Flask, render_template, request, redirect, url_for
import json
from pathlib import Path

app = Flask(__name__)

DATA = Path("data")
PROJECTS_FILE = DATA / "projects.json"
STUDENTS_FILE = DATA / "students.json"

def load_json(path):
    if not path.exists():
        return []
    with open(path, "r", encoding="utf-8") as f:
        return json.load(f)

def save_json(path, data):
    with open(path, "w", encoding="utf-8") as f:
        json.dump(data, f, indent=2, ensure_ascii=False)

@app.route("/")
def index():
    projects = load_json(PROJECTS_FILE)
    students = load_json(STUDENTS_FILE)
    return render_template("index.html", projects=projects, students=students)

@app.route("/projects/add", methods=["POST"])
def add_project():
    projects = load_json(PROJECTS_FILE)
    projects.append({
        "name": request.form["name"],
        "runtime": request.form["runtime"],
        "status": "ACTIVE"
    })
    save_json(PROJECTS_FILE, projects)
    return redirect(url_for("index"))

@app.route("/students/add", methods=["POST"])
def add_student():
    projects = load_json(PROJECTS_FILE)

    if len(projects) == 0:
        return "At least one project is required."

    students = load_json(STUDENTS_FILE)

    students.append({
        "name": request.form["name"],
        "project": request.form["project"],
        "chrome_profile": f'browser_runtime/{request.form["name"]}',
        "status": "ACTIVE"
    })

    save_json(STUDENTS_FILE, students)
    return redirect(url_for("index"))

if __name__ == "__main__":
    app.run(debug=True)
